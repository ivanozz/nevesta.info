﻿<?php
/**
 * константы подключения к бд
 */
define("INITIAL_QUERY", "");
define("SQL_LOGIN", "mysql");
define("SQL_PASSWD", "mysql");
define("SQL_HOST", "localhost");
define("SQL_DBASE", "nevesta");
define("TABLE_PREFIX", "nevesta");

